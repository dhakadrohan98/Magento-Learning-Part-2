<?php
namespace Sigma\Careers\Api\Data;

interface GridInterface
{
    /**
     * Constants for keys of data array. Identical to the name of the getter in snake case.
     */
    public const ID = 'id';
    public const NAME = 'name';
    public const EMAIL = 'email';
    public const MOBILE = 'mobile';
    public const SPECIALIZATION = 'specialization';
    public const CV = 'cv';
    public const CV_FILE_NAME = 'cv_file_name';
    public const CREATED_AT = 'created_at';
    /**
     * Get Id.
     *
     * @return int
     */
    public function getId();

    /**
     * Set Id.
     *
     * @param int $id
     */
    public function setId($id);

    /**
     * Get Name.
     *
     * @return varchar
     */
    public function getName();

    /**
     * Set Name
     *
     * @param string $name
     */
    public function setName($name);
    /**
     * Get Email.
     *
     * @return varchar
     */
    public function getEmail();
    /**
     * Set Email
     *
     * @param string $email
     */
    public function setEmail($email);
    /**
     * Get Specialization.
     *
     * @return varchar
     */
    public function getSpecialization();
     /**
      * Set Specialization.
      *
      * @param string $specialization
      */
    public function setSpecialization($specialization);
    /**
     * Get Mobile.
     *
     * @return varchar
     */
    public function getMobile();
    /**
     * Set Mobile.
     *
     * @param int $mobile
     */
    public function setMobile($mobile);
    /**
     * Get CV.
     *
     * @return varchar
     */
    public function getCV();
    /**
     * Set CV.
     *
     * @param string $cv
     */
    public function setCV($cv);
    /**
     * Get CV file name.
     */
    public function getCVFileName();
    /**
     * Set CV file name.
     *
     * @param string $cvFileName
     */
    public function setCVFileName($cvFileName);
    /**
     * Get Created At.
     *
     * @return varchar
     */
    public function getCreatedAt();
    /**
     * Set Created At.
     *
     * @param string $createdAt
     */
    public function setCreatedAt($createdAt);
}
