<?php
/**
 * @category  Sigma
 * @package   Sigma_ClearCartGraphQl
 * @author    SigmaInfo Team
 * @copyright 2021 Sigma (https://www.sigmainfo.net/)
 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Sigma_ClearCartGraphQl',
    __DIR__
);
