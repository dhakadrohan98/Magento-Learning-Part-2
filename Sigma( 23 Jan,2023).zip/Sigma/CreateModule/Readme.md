/*
 * @package        Ritesh_Rana
 * @author         Ritesh Rana
 */

 To create Module run below command:

 **bin/magento create:module <Vendor Name> <Module Name>**
 
**example**
**bin/magento create:module Magento Module**


 It will generate Directory as:

    Vendor
          |
          Module
                |__etc
                |     | module.xml
                |
                |__ registration.php












