<?php
/*
 * @package        Ritesh_Rana
 * @author         Ritesh Rana
 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Sigma_CreateModule',
    __DIR__
);
