<?php
/**
 * @category  Sigma
 * @package   Sigma_ProductMediaGalleryGraphQl
 * @author    SigmaInfo Team
 * @copyright 2021 Sigma (https://www.sigmainfo.net/)
 */

use Magento\Framework\Component\ComponentRegistrar;

ComponentRegistrar::register(ComponentRegistrar::MODULE, 'Sigma_ProductMediaGalleryGraphQl', __DIR__);
