<?php

/**
 * @category  Sigma
 * @package   Sigma_SAPIntegration
 * @author    SigmaInfo Team
 * @copyright 2022 Sigma (https://www.sigmainfo.net/)
 */

namespace Sigma\SAPIntegration\Model;

use GuzzleHttp\Client;
use GuzzleHttp\ClientFactory;
use GuzzleHttp\Exception\GuzzleException;
use GuzzleHttp\Psr7\Response;
use GuzzleHttp\Psr7\ResponseFactory;
use Magento\Framework\Webapi\Rest\Request;
use Psr\Log\LoggerInterface;

class CustomerDetails
{

    /**
     * API request URL
     */
    //const API_REQUEST_URI = 'https://amcdev:44303/';
    protected $urlPrefix = 'https://amcdev:44303/';

    /**
     * API request endpoint
     */
    //const API_REQUEST_ENDPOINT = 'sap/opu/odata/sap/ZMM_MATMASTER_SRV/MatConSet?$format=json';
    protected $apiUrl = 'sap/opu/odata/sap/ZSD_CUSTMASTER_SRV/CustMastSet?$format=json';
    protected $userName = "AMCESHOP";
    protected $password = "adwan118";

    protected $adminUsername = "jinal";
    protected $adminPassword = "Jinal@123";
    /**
     * @var ResponseFactory
     */
    private $responseFactory;

    /**
     * @var ClientFactory
     */
    private $clientFactory;

    /**
     * GitApiService constructor
     *
     * @param ClientFactory $clientFactory
     * @param ResponseFactory $responseFactory
     */
    public function __construct(
        Client $guzzleClient,
        ResponseFactory $responseFactory,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\UrlInterface $urlInterface
    ) {
        $this->responseFactory = $responseFactory;
        $this->guzzleClient = $guzzleClient;
        $this->_storeManager = $storeManager;
        $this->_urlInterface = $urlInterface;
    }
    /** 
     * @return string
     */
    public function getUrlPrefix()
    {
        return $this->_storeManager->getStore()->getBaseUrl();
    }

    /**
     * Fetch data from API
     */
    public function customerInfo()
    {
        //echo "hi from customer cron";
        // exit;
        $authorization = 'Basic '.base64_encode($this->userName.':'.$this->password);
        $headers = array(
            'Content-Type' => 'application/json',
            'Accept' => 'application/json',
            'Authorization' => $authorization
        );

        $response =  $this->guzzleClient->request('GET', $this->urlPrefix.$this->apiUrl, array(
            'headers' => $headers
            )
        );

        // $rest = '{
        //     "d": {
        //     "results": [
        //     {
        //     "__metadata": {
        //     "id": "https://amcdev:44303/sap/opu/odata/sap/ZSD_CUSTMASTER_SRV/CustMastSet()",
        //     "uri": "https://amcdev:44303/sap/opu/odata/sap/ZSD_CUSTMASTER_SRV/CustMastSet()",
        //     "type": "ZSD_CUSTMASTER_SRV.CustMast"
        //     },
        //     "Kunnr": "CASH E-SHP",
        //     "Name1": "E1 Cash E-Shop",
        //     "Name2": "",
        //     "Email": "abc@adwan.com",
        //     "PostCode": "11111",
        //     "Street": "stree1",
        //     "Region": "RY",
        //     "City": "Riyadh",
        //     "TelNumber": "096612345678",
        //     "Country": "SA",
        //     "DefShip": "",
        //     "DefBill": ""
        //     },
        //     {
        //     "__metadata": {
        //     "id": "https://amcdev:44303/sap/opu/odata/sap/ZSD_CUSTMASTER_SRV/CustMastSet()",
        //     "uri": "https://amcdev:44303/sap/opu/odata/sap/ZSD_CUSTMASTER_SRV/CustMastSet()",
        //     "type": "ZSD_CUSTMASTER_SRV.CustMast"
        //     },
        //     "Kunnr": "C1 ESALES",
        //     "Name1": "Adwan Marketing E-Shop Sales",
        //     "Name2": "",
        //     "Email": "pervaiz@adwanmarketing.com",
        //     "PostCode": "",
        //     "Street": "",
        //     "Region": "",
        //     "City": "",
        //     "TelNumber": "00966-11-495-...",
        //     "Country": "SA",
        //     "DefShip": "",
        //     "DefBill": ""
        //     }
        //     ]
        //     }
        //     }';
            $res = json_decode($response,true);
            print_r($res);
            foreach($res["d"]["results"] as $data)
            {
                $customerArray=array_slice($data,2);
                $this->createCustomers($customerArray);
            }
      //      exit();

     //  exit();
    }

    /**
     * Get Admin Token via Admin Integration API
     */
    public function getAdminToken()
    {
        $headers = array(
            'Content-Type' => 'application/json',
            'Accept' => 'application/json',
        );
        $request_body = array(
            'username' => $this->adminUsername,
            'password' => $this->adminPassword
        );
        $apiUrl = $this->getUrlPrefix() . "rest/default/V1/integration/admin/token";
        $response =  $this->guzzleClient->request('POST', $apiUrl, array(
            'headers' => $headers,
            'json' => $request_body,
            )
        );
        return $response;
    }
    /**
     * Create Products
     *
     * @param [string] $adminToken
     * @return void
     */
    public function createCustomers($request_body)
    {
        $adminToken = $this->getAdminToken();
        $authorization = 'Bearer '.$adminToken;
        $headers = array(
            'Content-Type' => 'application/json',
            'Accept' => 'application/json',
            'Authorization' => $authorization
        );
        $apiUrl = $this->getUrlPrefix() . "rest/default/V1/customers";
        $response =  $this->guzzleClient->request('POST', $apiUrl, array(
            'headers' => $headers,
            'json' => [
                'customer' => $request_body
            ],
            )
        );
        return $response;
    }
}
