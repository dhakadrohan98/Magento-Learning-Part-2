<?php
/**
 * @category  Sigma
 * @package   Sigma_SAStateList
 * @author    SigmaInfo Team
 * @copyright 2021 Sigma (https://www.sigmainfo.net/)
 */
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Sigma_SAStateList',
    __DIR__
);
