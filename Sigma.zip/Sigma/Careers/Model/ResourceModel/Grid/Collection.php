<?php

/**
 * @category Sigma
 * @author SigmaInfo Team
 */

namespace Sigma\Careers\Model\ResourceModel\Grid;

class Collection extends \Magento\Framework\View\Element\UiComponent\DataProvider\SearchResult
{
    /**
     * @var string
     */
    protected $_idFieldName = 'id';

    /**
     * @var string
     */
    protected $_eventPrefix = 'sigma_careers_grid_collection';

    /**
     * @var string
     */
    protected $_eventObject = 'grid_collection';

    /**
     * Define the resource model & the model.
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(\Sigma\Careers\Model\Grid::class);
        $this->_init(\Sigma\Careers\Model\ResourceModel\Grid::class);
    }
}
