<?php

/**
 * @category  Sigma
 * @package   Sigma_SAPIntegration
 * @author    SigmaInfo Team
 * @copyright 2022 Sigma (https://www.sigmainfo.net/)
 */

namespace Sigma\SAPIntegration\Model;

use GuzzleHttp\Client;
use GuzzleHttp\ClientFactory;
use GuzzleHttp\Exception\GuzzleException;
use GuzzleHttp\Psr7\Response;
use GuzzleHttp\Psr7\ResponseFactory;
use Magento\Framework\Webapi\Rest\Request;
use Psr\Log\LoggerInterface;
use Magento\Catalog\Model\ProductFactory;

class ProductDetails
{

    /**
     * API request URL
     */
    //const API_REQUEST_URI = 'https://amcdev:44303/';
    protected $urlPrefix = 'https://amcdev:44303/';

    /**
     * API request endpoint
     */
    //const API_REQUEST_ENDPOINT = 'sap/opu/odata/sap/ZMM_MATMASTER_SRV/MatConSet?$format=json';
    protected $apiUrl = 'sap/opu/odata/sap/ZMM_MATMASTER_SRV/MatConSet?$format=json';
    protected $userName = "AMCESHOP";
    protected $password = "adwan118";

    protected $adminUsername = "jinal";
    protected $adminPassword = "Jinal@123";
    /**
     * @var ProductFactory
     */
    protected $_productResourceModel;

    /**
     * @var ResponseFactory
     */
    private $responseFactory;

    /**
     * @var ClientFactory
     */
    private $clientFactory;

    /**
     * GitApiService constructor
     *
     * @param ClientFactory $clientFactory
     * @param ResponseFactory $responseFactory
     */
    public function __construct(
        Client $guzzleClient,
        ResponseFactory $responseFactory,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\UrlInterface $urlInterface,
        ProductFactory $productFactory
    ) {
        $this->responseFactory = $responseFactory;
        $this->guzzleClient = $guzzleClient;
        $this->_storeManager = $storeManager;
        $this->_urlInterface = $urlInterface;
        $this->_productFactory = $productFactory;
    }
    /**
     * @return string
     */
    public function getUrlPrefix()
    {
        return $this->_storeManager->getStore()->getBaseUrl();
    }

    /**
     * Fetch data from API
     */
    public function productInfo()
    {
        // var_dump(openssl_get_cert_locations());
        // echo "openssl.cafile: ", ini_get('openssl.cafile'), "\n";
        // echo "curl.cainfo: ", ini_get('curl.cainfo'), "\n";
        //exit;
        echo "hi from product";

        $authorization = 'Basic '.base64_encode($this->userName.':'.$this->password);
        $headers = array(
            'Content-Type' => 'application/json',
            'Accept' => 'application/json',
            'Authorization' => $authorization
        );

        $response =  $this->guzzleClient->request('GET', $this->urlPrefix.$this->apiUrl, array(
            'headers' => $headers
            )
        );
        $res = json_decode($response, true);
        // $res='{
        //     "d": {
        //     "results": [
        //     {
        //     "__metadata": {
        //     "id": "https://amcdev:44303/sap/opu/odata/sap/ZMM_MATMASTER_SRV/MatConSet()",
        //     "uri": "https://amcdev:44303/sap/opu/odata/sap/ZMM_MATMASTER_SRV/MatConSet()",
        //     "type": "ZMM_MATMASTER_SRV.MatCon"
        //     },
        //     "Ersda": null,
        //     "Sku": "MSC-10CX1-5MM2",
        //     "Name": "10CX1.5MM2 INST. CABLE  CU/PVC/PVC  O/A",
        //     "AttributeSetId": "4",
        //     "Price": "0.01",
        //     "Status": "1",
        //     "Visibility": "4",
        //     "TypeId": "Simple",
        //     "Weight": "0.00",
        //     "Qty": "0.00",
        //     "IsInStock": "F",
        //     "CategoryId": "",
        //     "Mediia": "",
        //     "CustomAttr": ""
        //     },
        //     {
        //     "__metadata": {
        //     "id": "https://amcdev:44303/sap/opu/odata/sap/ZMM_MATMASTER_SRV/MatConSet()",
        //     "uri": "https://amcdev:44303/sap/opu/odata/sap/ZMM_MATMASTER_SRV/MatConSet()",
        //     "type": "ZMM_MATMASTER_SRV.MatCon"
        //     },
        //     "Ersda": null,
        //     "Sku": "MSC-12CX2-5-MM",
        //     "Name": "POWER CABLE CU/XLPE/CUT/PVC/600/1000V",
        //     "AttributeSetId": "4",
        //     "Price": "0.01",
        //     "Status": "1",
        //     "Visibility": "4",
        //     "TypeId": "Simple",
        //     "Weight": "0.00",
        //     "Qty": "0.00",
        //     "IsInStock": "F",
        //     "CategoryId": "",
        //     "Mediia": "",
        //     "CustomAttr": ""
        //     },
        //     {
        //     "__metadata": {
        //     "id": "https://amcdev:44303/sap/opu/odata/sap/ZMM_MATMASTER_SRV/MatConSet()",
        //     "uri": "https://amcdev:44303/sap/opu/odata/sap/ZMM_MATMASTER_SRV/MatConSet()",
        //     "type": "ZMM_MATMASTER_SRV.MatCon"
        //     },
        //     "Ersda": null,
        //     "Sku": "MSC-12PX18AWG",
        //     "Name": "INST. CABLE  CU/XLPE/SWA/PVC IS+OS SHIEL",
        //     "AttributeSetId": "4",
        //     "Price": "0.01",
        //     "Status": "1",
        //     "Visibility": "4",
        //     "TypeId": "Simple",
        //     "Weight": "0.00",
        //     "Qty": "0.00",
        //     "IsInStock": "F",
        //     "CategoryId": "",
        //     "Mediia": "",
        //     "CustomAttr": ""
        //     },
        //     {
        //     "__metadata": {
        //     "id": "https://amcdev:44303/sap/opu/odata/sap/ZMM_MATMASTER_SRV/MatConSet()",
        //     "uri": "https://amcdev:44303/sap/opu/odata/sap/ZMM_MATMASTER_SRV/MatConSet()",
        //     "type": "ZMM_MATMASTER_SRV.MatCon"
        //     },
        //     "Ersda": null,
        //     "Sku": "MSC-04014-T-CABLE",
        //     "Name": "Twisted Pair Cable \n0424 Inst. Cable Shi",
        //     "AttributeSetId": "4",
        //     "Price": "11.00",
        //     "Status": "1",
        //     "Visibility": "4",
        //     "TypeId": "Simple",
        //     "Weight": "0.00",
        //     "Qty": "96.00",
        //     "IsInStock": "T",
        //     "CategoryId": "",
        //     "Mediia": "",
        //     "CustomAttr": ""
        //     }
        //     ]
        //     }
        //     }
        //     ';
           // $rest = json_decode($res,true);
            foreach($res["d"]["results"] as $data)
            {
                print_r(array_slice($data,2));
                if($data["Sku"]!=''){
                    $sku = $data["Sku"];
                    $existSku = $this->isProductExist($sku);
                    $productArray = array_slice(array_slice($data,2));
                    if ($existSku > 0) {
                        $this->updateProducts($sku, $productArray);
                    } else {
                        $this->createProducts($productArray);
                    }
                }

            }
    }

    /**
     * Get Admin Token via Admin Integration API
     */
    public function getAdminToken()
    {
        $headers = array(
            'Content-Type' => 'application/json',
            'Accept' => 'application/json',
        );
        $request_body = array(
            'username' => $this->adminUsername,
            'password' => $this->adminPassword
        );
        $apiUrl = $this->getUrlPrefix() . "rest/default/V1/integration/admin/token";
        $response =  $this->guzzleClient->request('POST', $apiUrl, array(
            'headers' => $headers,
            'json' => $request_body,
            )
        );
        return $response;
    }
    /**
     * Create Products
     *
     * @param [string] $adminToken
     * @return void
     */
    public function createProducts($request_body)
    {
        $adminToken = $this->getAdminToken();
        $authorization = 'Bearer '.$adminToken;
        $headers = array(
            'Content-Type' => 'application/json',
            'Accept' => 'application/json',
            'Authorization' => $authorization
        );

        $apiUrl = $this->getUrlPrefix() . "rest/default/V1/products";
        $response =  $this->guzzleClient->request('POST', $apiUrl, array(
            'headers' => $headers,
            'json' => [
                'product' => $request_body
            ],
            )
        );
        return $response;
    }
    /**
     * @param $sku
     * @return false|int
     */
    public function isProductExist($sku): int
    {
        return $this->_productFactory->create()->getIdBySku($sku);
    }
    /**
     * Create Products
     *
     * @param [string] $adminToken
     * @return void
     */
    public function updateProducts($sku, $request_body)
    {
        $adminToken = $this->getAdminToken();
        $authorization = 'Bearer '.$adminToken;
        $headers = array(
            'Content-Type' => 'application/json',
            'Accept' => 'application/json',
            'Authorization' => $authorization
        );

        $apiUrl = $this->getUrlPrefix() . "rest/default/V1/products/".$sku;
        $response =  $this->guzzleClient->request('POST', $apiUrl, array(
            'headers' => $headers,
            'json' =>  [
                'product' => $request_body
            ],
            )
        );
        return $response;
    }
}
